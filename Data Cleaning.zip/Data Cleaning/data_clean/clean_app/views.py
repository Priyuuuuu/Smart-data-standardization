
from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
import pandas as pd
from .models import UploadedFile

def home(request):
    return render(request, 'upload.html')

def upload_file(request):
    if request.method == "POST":
        if "file" not in request.FILES:  
            return render(request, "upload.html", {"error": "No file uploaded. Please select a file."})

        file = request.FILES["file"]
        fs = FileSystemStorage()
        filename = fs.save(file.name, file)
        file_path = fs.path(filename)

        # Load Data with Encoding Handling
        try:
            if filename.endswith(".csv"):
                try:
                    df = pd.read_csv(file_path, encoding="utf-8")
                except UnicodeDecodeError:
                    try:
                        df = pd.read_csv(file_path, encoding="ISO-8859-1")  # Try Latin-1
                    except UnicodeDecodeError:
                        df = pd.read_csv(file_path, encoding="utf-16")  # Try UTF-16
                file_ext = "csv"

            elif filename.endswith((".xls", ".xlsx")):
                df = pd.read_excel(file_path)
                file_ext = "excel"
            else:
                return render(request, "upload.html", {"error": "Unsupported file format. Please upload CSV or Excel."})

        except Exception as e:
            return render(request, "upload.html", {"error": f"Error reading file: {str(e)}"})

        # Initial Stats
        total_rows, total_cols = df.shape

        # Data Cleaning
        errors = detect_errors(df)
        duplicate_count = df.duplicated().sum()
        df_cleaned = remove_duplicates(df)
        missing_values_count = df_cleaned.isnull().sum().sum()
        df_cleaned = handle_missing_values(df_cleaned)
        df_cleaned = standardize_data(df_cleaned)

        # Save Cleaned File
        cleaned_filename = "cleaned_" + filename
        cleaned_path = fs.path(cleaned_filename)
        if file_ext == "csv":
            df_cleaned.to_csv(cleaned_path, index=False, encoding="utf-8")
        else:
            df_cleaned.to_excel(cleaned_path, index=False)

        # Generate Report
        report = f"""
        DATA CLEANING REPORT

        Total Rows: {total_rows}  
        Total Columns: {total_cols}  
        Errors Detected: {len(errors)} columns had issues  
        Duplicates Removed: {duplicate_count}  
        Missing Values Filled: {missing_values_count}  
        Standardization Applied: Dates and text formatting standardized  
        """

        # Save report to a text file
        report_filename = "cleaning_report.txt"
        report_path = fs.path(report_filename)
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report)

        # Store file reference in database
        UploadedFile.objects.create(file=cleaned_filename)

        return render(request, "result.html", {
            "errors": errors,
            "cleaned_file": cleaned_filename,
            "report": report
        })

    return render(request, "upload.html")

#  Error Detection
def detect_errors(df):
    errors = {}
    for col in df.columns:
        if df[col].dtype == "object":  # Text columns
            errors[col] = df[col][df[col].str.contains(r"[^a-zA-Z0-9\s]", na=False)].tolist()
        elif df[col].dtype in ["int64", "float64"]:  # Numeric columns
            errors[col] = df[col][df[col] < 0].tolist()  # Detect negative values
    return errors

#  Remove Duplicates
def remove_duplicates(df):
    return df.drop_duplicates()

#  Handle Missing Values
def handle_missing_values(df):
    for col in df.columns:
        if df[col].dtype in ["int64", "float64"]:
            df[col].fillna(df[col].mean(), inplace=True)  # Fill with mean
        else:
            df[col].fillna("Unknown", inplace=True)  # Fill text with "Unknown"
    return df

#  Standardization (Fix Date Formats, Capitalization)
def standardize_data(df):
    for col in df.columns:
        if "date" in col.lower():
            df[col] = pd.to_datetime(df[col], errors="coerce").dt.strftime("%Y-%m-%d")  # Convert to YYYY-MM-DD
        elif df[col].dtype == "object":
            df[col] = df[col].str.strip().str.title()  # Capitalize words
    return df
