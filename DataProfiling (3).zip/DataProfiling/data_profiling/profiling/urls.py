
#used
from django.urls import path
from . import views

from django.contrib import admin
from django.urls import path
from django.conf import settings  # Import settings
from django.conf.urls.static import static 

urlpatterns = [
    path('', views.index, name='index'),
    path('home/', views.home, name='home'),
    path('upload/', views.upload_file, name='upload_file'),
    path('result/', views.databot_result, name='databot_result'),
    path('upload-dataset/', views.upload_dataset, name='upload_dataset'),
    path('ask/', views.ask_question, name='ask_question'),
    
]

# Serve media files during development (only if DEBUG is True)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



