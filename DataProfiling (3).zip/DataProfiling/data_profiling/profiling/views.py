# #Dta Profiling
# from django.shortcuts import render, redirect
# from django.http import HttpResponse
# from django.core.files.storage import FileSystemStorage
# import pandas as pd
# import os
# #DATA BOT
# import google.generativeai as genai
# from django.conf import settings
# from django.http import JsonResponse
# from django.conf import settings
# from django.urls import reverse


# # Settings for file upload path
# UPLOAD_DIR = os.path.join(os.path.dirname(__file__), 'uploads')
# os.makedirs(UPLOAD_DIR, exist_ok=True)

# def index(request):
#     return render(request, 'index.html')

# def home(request):
#     return render(request, 'home.html')

# def upload_file(request):
#     if request.method == 'POST' and request.FILES.get('dataset'):
#         dataset = request.FILES['dataset']
#         fs = FileSystemStorage(location=UPLOAD_DIR)
#         file_path = fs.save(dataset.name, dataset)
#         file_full_path = os.path.join(UPLOAD_DIR, file_path)

#         # Process the uploaded file
#         profiling_results = process_dataset(file_full_path)
        
#         # Remove the uploaded file after processing
#         os.remove(file_full_path)
        
#         return render(request, 'results.html', {'results': profiling_results})
#     else:
#         return HttpResponse("No file uploaded.")

# def process_dataset(file_path):
#     try:
#         # Read the dataset
#         if file_path.endswith('.csv'):
#             df = pd.read_csv(file_path)
#         elif file_path.endswith(('.xls', '.xlsx')):
#             df = pd.read_excel(file_path)
#         else:
#             return {"error": "Unsupported file format."}

#         # Profiling results
#         profiling_results = {}

#         # Null value counts
#         profiling_results['null_values'] = df.isnull().sum().to_dict()

#         # Data types
#         profiling_results['data_types'] = df.dtypes.astype(str).to_dict()

#         # Basic statistics
#         profiling_results['statistics'] = df.describe(include='all').to_dict()

#         # Categorizing columns
#         profiling_results['categories'] = categorize_columns(df)

#         return profiling_results
#     except Exception as e:
#         return {"error": str(e)}

# def categorize_columns(df):
#     """
#     Categorizes columns based on their data type.
#     """
#     categories = {}
    
#     for column in df.columns:
#         dtype = df[column].dtype
#         if pd.api.types.is_numeric_dtype(dtype):
#             categories[column] = 'Numerical'
#         elif pd.api.types.is_object_dtype(dtype):
#             categories[column] = 'Categorical'
#         elif pd.api.types.is_datetime64_any_dtype(dtype):
#             categories[column] = 'DateTime'
#         else:
#             categories[column] = 'Other'
    
#     return categories



# # data bot---CODE
# # Load API Key from settings

# # Configure Gemini API Key from Django settings
# GEMINI_API_KEY = getattr(settings, "GOOGLE_API_KEY", None)

# if not GEMINI_API_KEY:
#     raise ValueError("⚠️ GOOGLE_API_KEY is not set in settings.py")

# genai.configure(api_key=GEMINI_API_KEY)

# def databot_result(request):
#     """Render the Data Bot result page."""
#     message = request.GET.get('message', '')  # Retrieve success message from GET params
#     return render(request, 'databot_result.html', {'message': message})

# def upload_dataset(request):
#     """Handles file upload and stores dataset path in session."""
#     if request.method == 'POST' and request.FILES.get('dataset'):
#         dataset = request.FILES['dataset']
#         fs = FileSystemStorage(location=settings.MEDIA_ROOT)  # Save in MEDIA_ROOT
#         filename = fs.save(dataset.name, dataset)
#         dataset_path = os.path.join(settings.MEDIA_ROOT, filename)

#         request.session['dataset_path'] = dataset_path  # Store dataset path in session
#         request.session.modified = True  # Ensure session updates

#         # Redirect to databot_result with a success message
#         return redirect(f"{reverse('databot_result')}?message=Dataset uploaded successfully!")

#     return render(request, 'databot_result.html')

# def ask_question(request):
#     """Handles user queries and retrieves answers from Google Gemini AI."""
#     dataset_path = request.session.get('dataset_path')

#     if request.method == 'POST' and dataset_path:
#         question = request.POST.get('question')

#         if not question:
#             return render(request, 'databot_result.html', {'error': 'Please enter a question'})

#         try:
#             # Load dataset
#             df = pd.read_csv(dataset_path)

#             # Convert only a sample of data to JSON to avoid exceeding model limits
#             df_json = df.head(5).to_dict(orient='records')

#             # AI Prompt
#             prompt = f"""
#             You are an AI assistant analyzing a structured dataset. The dataset contains these records:
            
#             {df_json}

#             Answer the user's question accurately based on this dataset.

#             User's Question: {question}
#             """

#             # Call Gemini API
#             model = genai.GenerativeModel("gemini-1.5-pro-latest")
#             response = model.generate_content(prompt)

#             # Ensure response exists
#             answer_text = response.text if hasattr(response, 'text') else "⚠️ No response generated."

#             return render(request, 'databot_result.html', {'answer': answer_text})

#         except Exception as e:
#             return render(request, 'databot_result.html', {'error': f"Error processing dataset: {str(e)}"})

#     return render(request, 'databot_result.html')


import os
import pandas as pd
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from django.urls import reverse
import chardet  # For automatic encoding detection
import google.generativeai as genai  # Gemini AI

# Configure Gemini API Key
GEMINI_API_KEY = getattr(settings, "GOOGLE_API_KEY", None)
if not GEMINI_API_KEY:
    raise ValueError("⚠️ GOOGLE_API_KEY is not set in settings.py")
genai.configure(api_key=GEMINI_API_KEY)

# Settings for file upload directory
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), 'uploads')
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Home Page
def index(request):
    return render(request, 'index.html')

def home(request):
    return render(request, 'home.html')


# File Upload Function
def upload_file(request):
    if request.method == 'POST' and request.FILES.get('dataset'):
        dataset = request.FILES['dataset']
        fs = FileSystemStorage(location=UPLOAD_DIR)
        file_path = fs.save(dataset.name, dataset)
        file_full_path = os.path.join(UPLOAD_DIR, file_path)

        # Process the uploaded file
        profiling_results = process_dataset(file_full_path)

        # Remove the uploaded file after processing
        os.remove(file_full_path)

        return render(request, 'results.html', {'results': profiling_results})
    
    return HttpResponse("No file uploaded.")

# Function to Detect File Encoding
def detect_encoding(file_path):
    with open(file_path, "rb") as f:
        result = chardet.detect(f.read(100000))  # Read first 100k bytes for encoding detection
    return result['encoding']

# Dataset Processing Function
def process_dataset(file_path):
    try:
        encoding = detect_encoding(file_path)  # Detect encoding

        # Read CSV or Excel file with the detected encoding
        if file_path.endswith('.csv'):
            df = pd.read_csv(file_path, encoding=encoding, on_bad_lines='skip')
        elif file_path.endswith(('.xls', '.xlsx')):
            df = pd.read_excel(file_path)
        else:
            return {"error": "Unsupported file format."}

        # Profiling results
        profiling_results = {
            'null_values': df.isnull().sum().to_dict(),
            'data_types': df.dtypes.astype(str).to_dict(),
            'statistics': df.describe(include='all').to_dict(),
            'categories': categorize_columns(df)
        }

        return profiling_results
    except Exception as e:
        return {"error": str(e)}

# Function to Categorize Columns
def categorize_columns(df):
    categories = {}
    for column in df.columns:
        dtype = df[column].dtype
        if pd.api.types.is_numeric_dtype(dtype):
            categories[column] = 'Numerical'
        elif pd.api.types.is_object_dtype(dtype):
            categories[column] = 'Categorical'
        elif pd.api.types.is_datetime64_any_dtype(dtype):
            categories[column] = 'DateTime'
        else:
            categories[column] = 'Other'
    return categories

# Data Bot (AI Chat Assistant)
def databot_result(request):
    message = request.GET.get('message', '')
    return render(request, 'databot_result.html', {'message': message})

# File Upload for Data Bot
def upload_dataset(request):
    if request.method == 'POST' and request.FILES.get('dataset'):
        dataset = request.FILES['dataset']
        fs = FileSystemStorage(location=settings.MEDIA_ROOT)
        filename = fs.save(dataset.name, dataset)
        dataset_path = os.path.join(settings.MEDIA_ROOT, filename)

        request.session['dataset_path'] = dataset_path
        request.session.modified = True

        return redirect(f"{reverse('databot_result')}?message=Dataset uploaded successfully!")

    return render(request, 'databot_result.html')

# Function to Answer Questions from the Dataset
def ask_question(request):
    dataset_path = request.session.get('dataset_path')

    if request.method == 'POST' and dataset_path:
        question = request.POST.get('question')
        if not question:
            return render(request, 'databot_result.html', {'error': 'Please enter a question'})

        try:
            encoding = detect_encoding(dataset_path)
            df = pd.read_csv(dataset_path, encoding=encoding, on_bad_lines='skip')

            df_json = df.head(5).to_dict(orient='records')

            prompt = f"""
            You are an AI analyzing a dataset. The dataset contains these records:
            
            {df_json}

            Answer the user's question based on this dataset.

            User's Question: {question}
            """

            model = genai.GenerativeModel("gemini-1.5-pro-latest")
            response = model.generate_content(prompt)
            answer_text = response.text if hasattr(response, 'text') else "⚠️ No response generated."

            return render(request, 'databot_result.html', {'answer': answer_text})

        except Exception as e:
            return render(request, 'databot_result.html', {'error': f"Error processing dataset: {str(e)}"})

    return render(request, 'databot_result.html')


#AUTOMATED DATA CLEAN
